<?php

namespace App\Models;
use CodeIgniter\Model;

class voiture extends Model
{
    
    
        protected $table      ='vehicule';
        protected $primaryKey ='id_vehicule';
        
        
        protected $useAutoIncrement =true;
        
        //protected returnType      ='array';
        protected $returnType       = '\App\Models\Entities\VoitureEntity';        
        protected $useSoftDeltes = false;
        
        protected $allowedFields = ['marque','modele','categorie'];
        
        protected $useTimestamps= false;
        
    
}
