<?php

namespace App\Models;
use CodeIgniter\Model;

class vehCatModel extends Model
{
    
    
        protected $table      ='veh_cat';
        protected $primaryKey ='id_categorie';
        
        
        protected $useAutoIncrement =true;
        
        //protected returnType      ='array';
        protected $returnType       = '\App\Models\Entities\VoitureCatEntity';        protected $useSoftDeltes = false;
        
        protected $allowedFields = ['categorie'];
        
        protected $useTimestamps= false;
        
    
}
