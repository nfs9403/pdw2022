<?php
 
namespace app\Models;
use CodeIgniter\Model;
 
 
class Authenticator {
public static function authenticate($email,$password){
$sql = "SELECT * FROM users WHERE email='".$email."'";
$db = \Config\Database::connect();
 
$user = null;
$query = $db->query($sql);
$results = $query->getResult();
foreach ($results as $row) {
    if(password_verify($password, $row->password)){
        $userModel = new \App\Models\UserModel();
        $user = $userModel->find($row->id_utilisateur);
        }
    }
        return $user;
    }
}
?>