<?php

namespace App\Models;
use CodeIgniter\Model;

class UserModel extends Model
{
    
    
        protected $table      ='users';
        protected $primaryKey ='id_utilisateur';
        
        protected $useAutoIncrement =true;
        
        //protected returnType      ='array';
        protected $returnType       = '\App\Models\Entities\UserEntity';        
        protected $useSoftDeltes = false;
        
        protected $allowedFields = ['lastname','firstname','email','password','avatar', 'id_role'];
        
        protected $useTimestamps= false;
        
    
}
