<?php

namespace App\Models;
use CodeIgniter\Model;

class TeamModel extends Model
{
    
    
        protected $table      ='team';
        
        
        //protected returnType      ='array';
        protected $returnType       = '\App\Models\Entities\TeamEntity';        
        protected $useSoftDeltes = false;
        
        protected $allowedFields = ['nom','prenom','fonction'];
        
        protected $useTimestamps= false;
        
    
}
