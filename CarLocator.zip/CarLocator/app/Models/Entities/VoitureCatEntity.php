<?php

namespace App\Models\Entities;

use CodeIgniter\Entity\Entity;

class VoitureCatEntity extends Entity
{
    public function getCat()
    {
        
        return $this->categorie;
    }

    
}
