<?php

namespace App\Models\Entities;

use CodeIgniter\Entity\Entity;

class VoitureEntity extends Entity
{
    public function getBrandName()
    {
        return $this->marque.' '. $this->modele.' '. $this->categorie;
    }

    
}
