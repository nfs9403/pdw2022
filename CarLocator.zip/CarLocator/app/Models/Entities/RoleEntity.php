<?php

namespace App\Models\Entities;

use CodeIgniter\Entity\Entity;

class RoleEntity extends Entity
{
    
    
}
