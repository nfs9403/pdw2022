<?php

namespace App\Models\Entities;

use CodeIgniter\Entity\Entity;

class UserEntity extends Entity
{
    public function getFullName()
    {
        
        return $this->lastname.' '. $this->firstname;
    }
    public function getRole()
    {
        $roleModel = new \App\Models\RoleModel();
        return $roleModel->find($this->id_role);
    }
    
}
