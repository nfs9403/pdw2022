<?php

namespace App\Models\Entities;

use CodeIgniter\Entity\Entity;

class TeamEntity extends Entity
{
    public function getName()
    {
        return $this->nom.' '. $this->prenom;
    }


}
