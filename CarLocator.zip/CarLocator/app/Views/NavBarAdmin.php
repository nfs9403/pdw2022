
    <!-- .navbar -->

    <nav class="navbar navbar-expand-lg navbar-toggler bg-dark fixed-top">
      <div class="container-fluid order-3">
        <a class="navbar-brand" href="<?php echo base_url('/Home/index'); ?>">
          <img  src="<?php echo base_url('assets/uploads/LogoCLocator.PNG'); ?>"  width="70" height="40" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-md-auto">
            <li class="nav-item">
              <a class="nav-link scrollto" href="#about">A propos de nous</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto " href="#portfolio">Nos Véhicules</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/admin'); ?>">Admin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/team'); ?>">Adminv2</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/veh'); ?>">BDE test</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/garage'); ?>">adminAcceuil</a>
            </li>
                                <?php 
                                if (isset($_SESSION['user'])) {
                                    echo '<li class="nav-item"><a data-bs-target="#profileModal" data-bs-toggle="modal" class="nav-link">Salut ' . (($_SESSION['user']->firstname) && ($_SESSION['user']->getRole())->id_role=="1")). '</a></li>';
                                    echo '<li class="nav-item">';
                                    echo '<a href="';
                                    echo base_url();
                                    echo '/Admin/acceuil" class="btn btn-info">Logout</a></li>';
                                } else {
                                          ?>
                                          <li class="nav-item">
                                          <a class="btn btn-info" data-bs-target="#myModal" data-bs-toggle="modal">Login</a>
                                          </li>

                                          <li class="nav-item">
                                          <a class="btn btn-info" data-bs-target="#inscriptionModal" data-bs-toggle="modal">Inscription</a>
                                          </li>
                                          <?php
                                      }
                                          ?>
        
                            
                            
        
          
      </ul>
        </div>

      </div>      


    </nav>

          <?php 
          include_once('login.php');
          ?>
          
          <?php 
          include_once('inscriptionModal.php');
          ?>

    <!-- .navbar -->
  