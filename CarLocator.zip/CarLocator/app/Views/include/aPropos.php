<section id="about" class="about section-bg">
      <div class="container">

        <div class="row">
          <div class="image col-xl-5 d-flex align-items-stretch justify-content-center justify-content-lg-start"></div>
          <div class="col-xl-7 pl-0 pl-lg-5 pr-lg-1 d-flex align-items-stretch">
            <div class="content d-flex flex-column justify-content-center">
              <h3 data-aos="fade-in" data-aos-delay="100">Depuis 1954, notre société Satisfait au mieux les touristes et tout autres clients</h3>
              <p data-aos="fade-in">
                Le plaisir de conduire n'est plus un luxe, désormais à l'aide de nos prix imbattables...
              </p>

              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up">
                  <i class="bx bx-receipt"></i>
                  <h4>Amour</h4>
                  <p>Une vue imprenable sur les routes</p>
                  <p>L'odeur du carburant dans les stations</p>
                </div>

                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
                  <i class="bx bx-cube-alt"></i>
                  <h4>Plaisir</h4>
                  <p>L'heure tourne, profitez un maximum </p>
                  <p>Des sensations qu'apporte la conduite</p>
                </div>

                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
                  <i class="bx bx-images"></i>
                  <h4>Relaxation</h4>
                  <p>Découvrez notre game élèctrique</p>
                  <p>La conduite la plus reactive dans le calme</p>
                  <p>Les sieges chauffants et massant</p>
                </div>

                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="300">
                  <i class="bx bx-shield"></i>
                  <h4>Liberté</h4>
                  <p>Une fois au volant, libérer votre instinct</p>
                  <p>Tout le monde cherche une manière d'être libre</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>