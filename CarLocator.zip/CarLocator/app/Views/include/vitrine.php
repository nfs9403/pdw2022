<section id="portfolio" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-in">Nos Véhicules</h2>
          <p data-aos="fade-in">Voici nos différentes voitures disponibles, il y en a pour tout les goûts!</p>
          <p>En partant du multivan familliale,</p>
          <p>Passant par la petite berline quotidienne,</p>
          <p>A une voiture qui vous donnera des frissons</p>
        </div>

        <div class="row">
          <div class="col-lg-12">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">Toutes</li>
              <li data-filter=".filter-app">Berline</li>
              <li data-filter=".filter-card">Familiale</li>
              <li data-filter=".filter-web">Sportive</li>
              <li data-filter=".BB" >Exclusivité online</li>
            </ul>
          </div>
        </div>
        <!-- 1 -->
        <div class="row portfolio-container" data-aos="fade-up">
          <div class="col-lg-4 col-md-6 portfolio-item filter-app" >
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/berline1.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <!-- 2x le lien : 1 pour l'image normal et l'autre pour l'image zoom -->
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/berline1.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 1"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>"
                  title="detailsVehicule"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Exclu 1</h4>
                <p>Exclusivité</p>
              </div>
            </div>
          </div>
          <!-- 2 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/familiale1.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/familiale1.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>toytota verso</h4>
                <p>pas oublier de noter autre chose ici</p>
              </div>
            </div>
          </div>
          <!-- 3 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/Sportive1.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/Sportive1.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 2"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Aston Martin</h4>
                <p>v8 coupé</p>
              </div>
            </div>
          </div>
          <!-- 4 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/familiale2.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/familiale2.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 2"><i class="bi bi-plus"></i></a>
                <a hhref="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Aston Martin</h4>
                <p>DBX</p>
              </div>
            </div>
          </div>
          <!-- 5 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/Sportive2.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/Sportive2.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 2"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Ferrari</h4>
                <p>FF</p>
              </div>
            </div>
          </div>
          <!-- 6 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/berline2.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/berline2.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 3"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>BMW</h4>
                <p>Serie 5</p>
              </div>
            </div>
          </div>
          <!-- 7 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-web BB">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/Sportive3.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/Sportive3.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 1"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Koenigsegg</h4>
                <p>Regera</p>
              </div>
            </div>
          </div>
          <!-- 8 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/berline3.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/berline3.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 3"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Tesla</h4>
                <p>Model S</p>
              </div>
            </div>
          </div>
          <!-- 9 -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url(). '/assets/uploads/vitrine/familiale3.jpg'; ?>" class="img-fluid" alt="" style="height:275px; width:450px;">
              <div class="portfolio-links">
                <a href="<?php echo base_url(). '/assets/uploads/vitrine/familiale3.jpg'; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bi bi-plus"></i></a>
                <a href="<?php echo base_url(). '/Home/voitureInfo'; ?>" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Toyota</h4>
                <p>Highlander Hybrid</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>