<section id="team" class="team section-bg">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-in">Dream Team</h2>
          <p data-aos="fade-in">Pas de panique, notre équipe est la meilleure. </p>
            <p> Son faisant référence a l'équipe de basket-ball des Jeux Olympique de 1992, </p>
            <p>Dans laquelle a été réuni les meilleurs joueurs</p>
        </div>
        
        <div class="row">
          <?php 
          foreach($teams as $key => $team){
          $imgPath=base_url('/assets/uploads/team').'/'.$team->photo;
          ?>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="member" data-aos="fade-up">
              <div class="pic"><img src="<?php echo $imgPath ; ?>" alt=""></div>
              <h4><?php echo $team->getName() ;?></h4>
              <span><?php echo $team->fonction ;?></span>
              <div class="social">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

          <?php
          }
          ?>
      </div>
    </section>