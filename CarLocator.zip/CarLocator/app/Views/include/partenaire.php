    <!-- Contenaire un seul par page ======= -->
    <section id="clients" class="clients section-bg">
      <div class="container">

        <div class="row no-gutters clients-wrap clearfix wow fadeInUp">

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo"
              <button class="bckgrdColor"
              data-toggle="collapse" data-target="#description">
              <img src="<?php echo base_url('assets/uploads/partenaire/p1.png'); ?>" class="img-fluid" alt="" data-aos="fade-up" data-aos-delay="100" width="80%">
            </div>
              <div id="description" class="collapse">
                <a href="https://www.bmw.be/fr/home.html" target="_blank"> 
                <?php echo "<span style='color:#007aff;'>Bmw</span>"; ?>
                </a>, voiture sexy et vilaine
             </div> 
          </div>
          
          <!-- arriere plan d'icone a modifier deja tester avec ca
          type="hidden" background=white ou type="transparent" et meme taille-->
          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo"
              <button class="bckgrdColor"
              data-toggle="collapse" data-target="#description2">
              <img src="<?php echo base_url('assets/uploads/partenaire/p2.png'); ?>" class="img-fluid" alt="" data-aos="fade-up" data-aos-delay="200" width="60%">
            </div>
              <div id="description2" class="collapse">
                <a href="https://www.tesla.com/fr_be" target="_blank"> 
                <?php echo "<span style='color:#007aff;'>Tesla</span>"; ?>
                </a>, Laisser la vous guidez
             </div> 
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo"
              <button class="bckgrdColor"
              data-toggle="collapse" data-target="#description3">
              <img src="<?php echo base_url('assets/uploads/partenaire/p3.png'); ?>" class="img-fluid" alt="" data-aos="fade-up" data-aos-delay="300" width="65%">
            </div>
              <div id="description3" class="collapse">
                <a href="https://www.audi.be/" target="_blank"> 
                <?php echo "<span style='color:#007aff;'>Audi</span>"; ?>
                </a>, machine allemande a toute épreuve !
             </div> 
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo"
              <button class="bckgrdColor"
              data-toggle="collapse" data-target="#description4">
              <img src="<?php echo base_url('assets/uploads/partenaire/p4.png'); ?>" class="img-fluid" alt="" data-aos="fade-up" data-aos-delay="400" width="80%" >
            </div>
              <div id="description4" class="collapse">
                <a href="https://www.astonmartin.com/fr/" target="_blank"> 
                <?php echo "<span style='color:#007aff;'>Aston Martin</span>"; ?>
                </a>: Éllegance, puissance et plaisir de conduite
             </div> 
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo"
              <button class="bckgrdColor" data-toggle="collapse" data-target="#description5" >
              <img src="<?php echo base_url('assets/uploads/partenaire/p5.png'); ?>" class="img-fluid" alt="" data-aos="fade-up" data-aos-delay="500" width="50%" >
            </div>
              <div id="description5" class="collapse">
                <a href="https://fr.toyota.be/" target="_blank"> 
                <?php echo "<span style='color:#007aff;'>Toyota</span>"; ?>
                </a>, Leader mondial de l'automobile pour une raison
             </div> 
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo"
              <button class="bckgrdColor"
              data-toggle="collapse" data-target="#description6">
              <img src="<?php echo base_url('assets/uploads/partenaire/p6.png'); ?>" class="img-fluid" alt="" data-aos="fade-up" data-aos-delay="600" >
            </div>
              <div id="description6" class="collapse">
                <a href="https://www.koenigsegg.com/" target="_blank"> 
                <?php echo "<span style='color:#007aff;'>Koenigsegg</span>"; ?>
                </a>La Suédoise #RecordBreaker et innovante !
             </div> 
          </div>

        </div>

      </div>
    </section>