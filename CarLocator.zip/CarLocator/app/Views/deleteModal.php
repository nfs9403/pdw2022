          <!-- MODAL -->
          
          <div class="modal fade" id="del<?php echo $user->id_utilisateur ?>" tableindex="-1" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">êtes-vous sur de vouloir supprimer ce client ?</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>

                  <form action="<?php echo base_url(); ?>/home/delete/<?php echo $user->id_utilisateur; ?>" method="POST">
                    <button type="submit" class="btn btn-primary">Supprimer</button>
                  </form>
                </div>
              </div>
            </div>