<!DOCTYPE html>
<html lang="fr">

<head>
    
<script src="<?php echo base_url(). '/assets/swiper/swiper-bundle.min.js';?>"></script>
<?php 
    include_once('include/lien.php');
?>
    <link href="<?php echo base_url(). '/assets/swiper/swiper-bundle.min.css'; ?>" rel="stylesheet">
</head>


<body>



  <!-- ======= Header ======= -->
  

  <main id="main">

  <!-- ======= Portfolio Details Section        a modifier carousel ou swiper et retirer css si pas swipper        ======= -->
    <section id="portfolio-details" class="portfolio-details carousel">
      <div class="carousel-inner">

        <div class="row gy-4">

          <div class="col-lg-8">
            <div class="portfolio-details-slider swiper ">
              <div class="swiper-wrapper align-items-center">

                <div class="swiper-slide carousel-item active " data-bs-interval="1000">
                  <img src="<?php echo base_url(). '/assets/uploads/vitrine/berline1.jpg'; ?>" alt="">
                </div>

                <div class="swiper-slide carousel-item" data-bs-interval="2000">
                  <img src="<?php echo base_url(). '/assets/uploads/vitrine/berline2.jpg'; ?>" alt="">
                </div>

                <div class="swiper-slide carousel-item">
                  <img src="<?php echo base_url(). '/assets/uploads/vitrine/berline3.jpg'; ?>" alt="">
                </div>

              </div>
              <div class="swiper-pagination"></div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="portfolio-info">
              <h3>Détails</h3>
              <ul>
                <li><strong>Categorie</strong>: Berline</li>
                <li><strong>Marque</strong>: audi</li>
                <li><strong>modele</strong>: A3</li>
                <li><strong>Lien de présentation</strong>: <a href="#">www.audi.be</a></li>
              </ul>
            </div>
            <div class="portfolio-description">
              <h2>Pourquoi cette catégorie ?</h2>
              <p>
                Pour être bref, comfort, place de rangement et plaisir de conduire sur les bords de mers
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- End Portfolio Details Section -->

  </main><!-- End #main -->
  

    <!-- ======= Pied de page ======= -->
    <?php 
        include_once('include/Footer.php');
    ?>

    <!-- Pied de page -->

</body>


</html>