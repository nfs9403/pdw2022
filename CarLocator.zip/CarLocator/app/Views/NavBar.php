    <nav class="navbar navbar-expand-lg navbar-toggler bg-dark fixed-top">
      <div class="container-fluid order-3">
        <a class="navbar-brand" href="<?php echo base_url('/Home/index'); ?>">
          <img  src="<?php echo base_url('assets/uploads/LogoCLocator.PNG'); ?>"  width="70" height="40" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-md-auto">
            <li class="nav-item">
              <a class="nav-link scrollto" href="#about">A propos de nous</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto " href="#portfolio">Nos Véhicules</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/admin'); ?>">Admin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/team'); ?>">Adminv2</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/veh'); ?>">BDE test</a>
            </li>
            <li class="nav-item">
              <a class="nav-link scrollto" href="<?php echo base_url('Home/garage'); ?>">adminAcceuil</a>
            </li>


<?php 

         $imgPath=base_url('assets/uploads/users/avatar.jpg');
         if(isset(session('user')->avatar)&& session('user')->avatar!=''){
           $imgPath=base_url('/assets/uploads/users/').'/'.session('user')->avatar;
     
         }
         ?>
        <?php if((isset($_SESSION['user'])) && ($_SESSION['user']->getRole())->name=="Admin"): ?> 
                     <?php echo base_url('/admin/AdminHome');?> 
          <div>
          <a href="<?php echo base_url();?>/home/logout" class="btn btn-info">Logout</a></li>
          </div>
       <?php  elseif((isset($_SESSION['user'])) && ($_SESSION['user']->getRole())->name=="User"):?>
            <li class="nav-item active colorMenu">
            <div class="dropdown container-fluid">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >Profil <span class="sr-only">(current)</span></a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#profileModal">Mon Profil</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/CarLocator/Home/logout">Déconnexion</a>
       </div>
          <a href="<?php echo base_url();?>/Home/logout" class="btn btn-info">Logout</a></li>
        </div>
        </div>

                     
                     
        <ul class="nav navbar-nav navbar-right">
          <li class="navbar-text"><a class="navbar-text">Salut  <?php echo $_SESSION['user']->lastname ; ?></a>
          </li>
        </ul>

        <img class="rounded-circle" src="<?php echo $imgPath;?>" alt="Generic placeholder image" width="60" height="70">
          
              <?php else :?>
                        <div class="d-flex">
                            
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <li class="nav-item">
                                          <a class="btn btn-info" data-bs-target="#myModal" data-bs-toggle="modal">Login</a>
                                          </li>

                                          <li class="nav-item">
                                          <a class="btn btn-info" data-bs-target="#inscriptionModal" data-bs-toggle="modal">Inscription</a>
                                          </li>
                  <!-- <li class="nav-item">
                 
      <a  class="btn btn-primary me-md-2" data-bs-target="#inscriptionModal" data-bs-toggle="modal" style="color:#FFFFFF">S'inscrire</a>
      </li>--></div>
              </div>
          <?php endif;?>

              </nav>
    
          <?php 
          include_once('login.php');
          ?>
          
          <?php 
          include_once('inscriptionModal.php');
          ?>
          
          <?php 
          include_once('profileModel.php');
          ?>