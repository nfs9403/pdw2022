<!-- ======= en-tête ======= -->

          <!-- inscription et login -->
           <?php 
                    if(isset($_SESSION['user'])){
                            echo '<li class="nav-item"><a class="nav-link">Salut '.$_SESSION['user']->firstname.'</a></li>'; 
                            echo '<li class="nav-item">';
                            echo '<a href="';
                            echo base_url();
                            echo '/Home/logout" class="btn btn-info">Logout</a></li>';
                             echo '<a class="btn btn-info" data-bs-toggle="modal" data-bs-target="#profileModel" >Mon Profil<a>';
                    }else{
                        ?>
                    <li class="nav-item">
                                <a class="btn btn-info" data-bs-target="#myModal" data-bs-toggle="modal">Login</a>
                    </li>
                    <?php
                    }
                    ?>
                    
                    <?php
                    if(!isset($_SESSION['user'])){
                        
                    ?>
                                
                     <li class="nav-item">
                                <a class="btn btn-info" data-bs-target="#inscriptionModal" data-bs-toggle="modal">Inscription</a>
                     </li>
                     <?php
                    }
                    ?>
          
          <!-- login inscription a arranger plus tard -->
        <?php 
          include_once('inscriptionModal.php');
        ?>
        <?php 
          include_once('login.php');
        ?>
        <?php 
          include_once('profileModel.php');
        ?>
        </ul>
        <!-- necessaire ?
        <i class="bi bi-list mobile-nav-toggle"></i> -->