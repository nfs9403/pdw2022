<!DOCTYPE html>
<html>
    <title>CarLocator</title>
  <head>

    <?php 
      include_once('include/lien.php');
    ?>
  </head>

  

<body>

    <?php 
        include_once('NavBar.php');
    ?>



  <!-- ======= Section page d'acceuil === ==== -->
  <section class="bg-dark text-light p-5 text center " id="Acceuil">

    <div class="container">
      <div class="row d-flex align-items-center">
        <div class=" col-lg-6 py-5 py-lg-0 order-2 order-lg-1" data-aos="fade-right">
          <h1>Votre nouvelle <span class="text-warning"> expérience de conduite</span></h1>
          <h5>Notre équipe est dévoué a vous satisfaire du mieux possible, le plaisir de conduire étant notre devise</h5>
          <a href="<?php echo base_url(). '/home/loginPage'; ?>" class="btn-get-started scrollto">C'est Parti</a>
        </div>
        <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left">
          <img src="<?php echo base_url(). '/assets/uploads/acceuil.png'; ?>" class="img-fluid" alt="" style="height:700px; width:770px;">
        </div>
      </div>
    </div>

  </section>
  <!-- Fin section page d'acceuil-->

  


    <!-- ======= Section partenaire ======= -->
    <?php 
          include_once('include/partenaire.php');
    ?>
    <!-- Fin Section partenaire-->



    <!-- ======= Section a propos ======= -->
    <?php 
          include_once('include/aPropos.php');
    ?>
    <!-- Fin Section a propos -->
    

    <!-- ======= Section vitrine ======= -->
      <?php 
        include_once('include/vitrine.php');
      ?>
      <!-- Fin section vitrine -->


    <!-- ======= Section Team ======= -->
        <?php 
          include_once('include/teamSection.php');
        ?>
    <!-- Fin Section Team-->
  
    
    <!-- ======= Pied de page ======= -->
        <?php 
          include_once('include/Footer.php');
        ?>
    <!-- Pied de page -->
  
    <!-- retour au top a supprimer ou reparer -->
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- dans le body, pq ? je ne sais pas -->
    <script>
    function sendForm(formId){
          $('#'+formId).submit();
    }
    </script>

</body>

    
</html>