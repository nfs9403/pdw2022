<!DOCTYPE html>
<html lang="fr">
    <!-- logo onglet -->
    <link href="assets/uploads/LogoCLocator.PNG" rel="icon">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    
    <!-- lien vers fichier CSS -->
    <link href="<?php echo base_url(). '/assets/css/stylePerso.css'; ?>" rel="stylesheet">
    <!-- Fichier JavaScript pour vitrine, image filtre  -->
    <script src="<?php echo base_url(). '/assets/js/main.js ';?>"></script>
    <script src="<?php echo base_url(). '/assets/js/isotope.pkgd.min.js';?>"></script>
    </script>
<head>

<!-- navbar -->
<nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="#about">A propos de nous</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Nos Véhicules</a></li>

          <li><a class="nav-link scrollto" href="#team">La Team</a></li>
          <li><a class="nav-link scrollto" href="<?php echo base_url(); ?>/Home/contact">xxxxx</a></li>
          <li class="dropdown"><a href="#"><span>Membre</span> 
          <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a data-bs-target="#myModal" data-bs-toggle="modal">Connexion</a></li>
              <li><a data-bs-target="#inscriptionModal" data-bs-toggle="modal">Inscription</a></li>
              <li><a href="#">lorsque session ouverte, devient btn de deconexion</a></li>
            </ul>
          <?php 
          include_once('login.php');
          ?>
          <?php 
          include_once('inscriptionModal.php');
          ?>
          </li>
        </ul>
      </nav><!-- .navbar -->

<h3>s,s,s,s,s,s,s</h3>
</head>

<body>




<!-- carte avec image et description -->

                    <div class="container padding ">
                    <div class="row padding">
                    <?php 
                    foreach($voitures as $key => $voiture){
                      $imgPath=base_url('/assets/uploads/voitures').'/'.$voiture->image;
                    ?>
                    <div class=" col-md-3">
                      <div class="card"  >
                        <img class="card-img-top" src="<?php echo $imgPath ; ?>"  alt="..." >
                        <div class="card-body">
                          <h5 class="card-title"><?php echo $voiture->getBrandName() ;?></h5>
                          <p class="card-text ">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                          <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                      </div>
                    </div>
                    <?php
                    }
                    ?>
                    </div>
                    </div>



<!-- fin carte avec image et description -->
<p>ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
ddddddddddddddd
</p>
<p>scssjsjlscjlsjlsjl</p>


 



  <p>ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
ddddddddddddddd
</p>
<p>scssjsjlscjlsjlsjl</p>


<div class="container padding ">
                    <div class="row padding">
                    <?php 
                    foreach($teams as $key => $team){
                      $imgPath=base_url('/assets/uploads/team').'/'.$team->photo;
                    ?>
                    <div class=" col-md-3">
                      <div class="card"  >
                        <img class="card-img-top" src="<?php echo $imgPath ; ?>"  alt="..." >
                        <div class="card-body">
                          <h5 class="card-title"><?php echo $team->getName() ;?></h5>
                          <p class="card-text ">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                          <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                      </div>
                    </div>
                    <?php
                    }
                    ?>
                    </div>
                    </div>




                    <section id="team" class="team section-bg">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-in">Dream Team</h2>
          <p data-aos="fade-in">Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>
        
        <div class="row">
          <?php 
          foreach($teams as $key => $team){
          $imgPath=base_url('/assets/uploads/team').'/'.$team->photo;
        ?>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="member" data-aos="fade-up">
              <div class="pic"><img src="<?php echo $imgPath ; ?>" alt=""></div>
              <h4>Walter White</h4>
              <span>Directeur Financier</span>
              <div class="social">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

        <?php
                    }
                    ?>
      </div>
    </section>




</body>

</html>