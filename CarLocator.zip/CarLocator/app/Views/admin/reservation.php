<!DOCTYPE html>
<html lang="en">
<head>
<title>Reservation</title>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
  	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- Bootstrap JS -->
  	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <!-- lien vers fichier CSS -->
      <link href="<?php echo base_url(). '/assets/css/admin.css'; ?>" rel="stylesheet">
</head>

<body>
<!-- Header section -->
<header>
  <button class="menu-toggle">
    <i class="fa fa-bars" aria-hidden="true"></i>
    <i class="fa fa-times" aria-hidden="true"></i>
  </button>
</header>

<!-- Sidebar Navigation -->
<div class="side-menu"> 
  <ul>
    <li><a href="<?php echo base_url('admin/utilisateurs'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Utilisateurs</a></li>
    <li><a href="<?php echo base_url('admin/vehicules'); ?>"><i class="fa fa-tablet" aria-hidden="true"></i> Véhicules</a></li>
    <li><a href="<?php echo base_url('admin/entreprise'); ?>"><i class="fa fa-fire" aria-hidden="true"></i> Entreprise</a></li>
    <li><a href="<?php echo base_url('admin/reservation'); ?>"><i class="fa fa-folder-open" aria-hidden="true"></i> Reservations</a></li>
    <li><a href="<?php echo base_url('admin/mails'); ?>"><i class="fa fa-play" aria-hidden="true"></i> Mails</a></li> 
  </ul>
</div>


    <!-- section Reservation -->
    <section id="book-a-table" class="book-a-table">
        <div class="container" data-aos="fade-up">
            <div class="row">
    			<div class="col-md-8 offset-md-2 text-center">
    				<h2 class="text-primary">Formulaire de réservation</h2>
    				<p class="mb-5">Veuillez remplir les données ci-joint pour pouvoir effectuer une réservation.</p>
    			</div>
    		</div>

            <form action="" method="post" role="form">
              <div class="form-row">
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="text" name="name" class="form-control" id="lastname " placeholder="Votre Nom de famille">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="text" name="name" class="form-control" id="firstname " placeholder="Votre Prénom">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Votre Email">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="number" class="form-control" name="phone" id="phone" placeholder="Votre N° de gsm">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="date" name="date" class="form-control" id="dateDepart" placeholder="Depart">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="time" class="form-control" name="time" id="heureDePriseEnMain" placeholder="Heure de depart">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="date" name="date" class="form-control" id="dateRetour" placeholder="Heure de retour">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="time" class="form-control" name="time" id="HeureDeRemise" placeholder="Time">
                </div>
                <div class="col-lg-4 col-md-6 form-group">
                    <input type="number" class="form-control" name="people" id="NombreDeConducteur" placeholder="Nombre de conducteurs">
                </div>
              </div>
              <div class="form-group">
                    <textarea class="form-control" name="message" placeholder="demande specifique"></textarea>
              </div>
              <button type="submit" class="btn btn-primary float-right mt-3">Réserver</button>
            </form>
        </div>
    </section>
    <!-- Fin section Reservation -->







</body>
<script>
$(document).ready(function(){
  $(".menu-toggle i").click(function(){
    $(".side-menu").css({
      left: '0px',
      transition: '0.5s'
    });
    $(".menu-toggle i.fa-bars, .menu-toggle i.fa-times").toggle();
  });
  $(".menu-toggle i.fa-times").click(function(){
    $(".side-menu").css({
      left: '-250px',
    });
  });
});
</script>
</html>
