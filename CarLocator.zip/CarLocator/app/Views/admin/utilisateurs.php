<!DOCTYPE html>
<html lang="fr">
<head>
  <title>Utilisateurs</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    
  <!-- lien vers fichier CSS -->
  <link href="<?php echo base_url(). '/assets/css/admin.css'; ?>" rel="stylesheet">
  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <!-- datatable -->
  <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" />
  <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
</head>

<style>
        .container-fluid{
            width: 1000px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
        .row{
          padding-top:50px;
        }

        .modal-dialog{
          padding-top:220px;
        }
    </style>

<body>
<!-- Header section -->
<header>
  <button class="menu-toggle">
    <i class="fa fa-bars" aria-hidden="true"></i>
    <i class="fa fa-times" aria-hidden="true"></i>
  </button>
</header>

<!-- Sidebar Navigation -->
<div class="side-menu"> 
  <ul>
    <li><a href="<?php echo base_url('admin/entreprise'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Entreprise</a></li>
    <li><a href="<?php echo base_url('admin/vehicules'); ?>"><i class="fa fa-tablet" aria-hidden="true"></i> Véhicules</a></li>
    <li><a href="<?php echo base_url('admin/utilisateurs'); ?>"><i class="fa fa-fire" aria-hidden="true"></i> Utilisateurs</a></li>
    <li><a href="<?php echo base_url('admin/reservation'); ?>"><i class="fa fa-folder-open" aria-hidden="true"></i> Reservations</a></li>
    <li><a href="<?php echo base_url('admin/mails'); ?>"><i class="fa fa-play" aria-hidden="true"></i> Mails</a></li>
     
  </ul>
</div>


  <div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="mt-5 mb-3 clearfix">
					<h2 class="pull-left">Voitures</h2>
					<a href="<?php echo base_url('Home/create'); ?>" class="btn btn-success pull-right">
					<i class="fa fa-plus"></i> Ajouter de nouvelles voitures</a>
				</div>
                    
                   
			
				<table class="datatable">
					<thead>
						<tr>
							<th>Id</th>
							<th>Nom</th>
							<th>Prénom</th>
							<th>Email</th>
							<th>Actions</th>
              <th>Actions</th>
						</tr>
					</thead>
					<tbody id="aa">
				
					<?php
						foreach ($users as $key => $user) {
						
						
						
							echo '<tr><td>' . $user->id_utilisateur . '</td>';
							echo '<td>' . $user->lastname . '</td>';
							echo '<td>' . $user->firstname . '</td>';
							echo '<td>' . $user->email . '</td>';				
							echo '<td><a data-bs-toggle="modal " data-bs-target="#upd' . $user->id_utilisateur . '" class="btn btn-warning">update</a></td>';
							echo '<td><a data-bs-toggle="modal" data-bs-target="#del' . $user->id_utilisateur . '" class="btn btn-danger">Delete</a></td>';
				  ?>

              <!-- MODAL -->
          
              <div class="modal fade" id="del<?php echo $user->id_utilisateur ?>" tableindex="-1" aria-labelledby="exampleModalLabel">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">êtes-vous sur de vouloir supprimer ce client ?</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <a>cette action est irreversible</a>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
    
                      <form action="<?php echo base_url(); ?>/Admin/delete/<?php echo $user->id_utilisateur; ?>" method="POST">
                        <button type="submit" class="btn btn-primary">Supprimer</button>
                      </form>
                    </div>
                  </div>
                </div>
								
							<?php
						?>

						<?php
						}
						?>

					</tbody>
					
				</table>                            
						
                </div>
            </div>        
			
        </div>
</body>
<script>
$(document).ready(function(){
  $(".menu-toggle i").click(function(){
    $(".side-menu").css({
      left: '0px',
      transition: '0.5s'
    });
    $(".menu-toggle i.fa-bars, .menu-toggle i.fa-times").toggle();
  });
  $(".menu-toggle i.fa-times").click(function(){
    $(".side-menu").css({
      left: '-250px',
    });
  });
});
</script>

<script>
  $(document).ready(function() {
  $('.datatable').DataTable();
});
</script>

</html>


