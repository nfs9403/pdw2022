<!DOCTYPE html>
<html>
    <title>Véhicules</title>
  <head>
    <?php 
      include_once('lien.php');
    ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <!-- lien vers fichier CSS -->
    <link href="<?php echo base_url(). '/assets/css/admin.css'; ?>" rel="stylesheet">
  </head>

  <header>
  <button class="menu-toggle">
    <i class="fa fa-bars" aria-hidden="true"></i>
    <i class="fa fa-times" aria-hidden="true"></i>
  </button>
  
</header>



<body>
<!-- Sidebar Navigation -->
<div class="side-menu"> 
  <ul>
    <li><a href="<?php echo base_url('admin/entreprise'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Entreprise</a></li>
    <li><a href="<?php echo base_url('admin/vehicules'); ?>"><i class="fa fa-tablet" aria-hidden="true"></i> Véhicules</a></li>
    <li><a href="<?php echo base_url('admin/utilisateurs'); ?>"><i class="fa fa-fire" aria-hidden="true"></i> Utilisateurs</a></li>
    <li><a href="<?php echo base_url('admin/reservation'); ?>"><i class="fa fa-folder-open" aria-hidden="true"></i> Reservations</a></li>
    <li><a href="<?php echo base_url('admin/mails'); ?>"><i class="fa fa-play" aria-hidden="true"></i> Mails</a></li>
     
  </ul>
</div>
<style>
  #a{
    background: rgb(76, 110, 221);

  }
  .card{
    margin-top:130px ;
    margin-left:50px ;
    margin-right:50px ;
    background: rgb(76, 221, 209);
  }
</style>


  <!-- ======= Section page d'acceuil === ==== -->
  <section id="a">

      <div class="row padding footer-top">
      <?php 
      foreach($voitures as $key => $voiture){
        $imgPath=base_url('/assets/uploads/voitures').'/'.$voiture->image;
      ?>
      <div class=" col-md-3">
        <div class="card"  >
          <img class="card-img-top" src="<?php echo $imgPath ; ?>"  alt="..." >
          <div class="card-body">
            <h5 class="card-title"><?php echo $voiture->getBrandName() ;?></h5>
            <p class="card-text "></p>
            <a href="<?php echo base_url('/home/voitureInfo'); ?>" class="btn btn-primary">Détails</a>
          </div>
        </div>
      </div>
      <?php
      }
      ?>
      </div>
      </div>
  </section>

</body>
<script>
$(document).ready(function(){
  $(".menu-toggle i").click(function(){
    $(".side-menu").css({
      left: '0px',
      transition: '0.5s'
    });
    $(".menu-toggle i.fa-bars, .menu-toggle i.fa-times").toggle();
  });
  $(".menu-toggle i.fa-times").click(function(){
    $(".side-menu").css({
      left: '-250px',
    });
  });
});
</script>
</html>
