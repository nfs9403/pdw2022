<!DOCTYPE html>
<html lang="fr">
<head>
  <title>Acceuil</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <!-- lien vers fichier CSS -->
      <link href="<?php echo base_url(). '/assets/css/admin.css'; ?>" rel="stylesheet">
</head>
<body>
<!-- Header section -->
<header>
  <button class="menu-toggle">
    <i class="fa fa-bars" aria-hidden="true"></i>
    <i class="fa fa-times" aria-hidden="true"></i>
  </button>
</header>

<!-- Sidebar Navigation -->
<div class="side-menu"> 
  <ul>
    <li><a href="<?php echo base_url('admin/entreprise'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Entreprise</a></li>
    <li><a href="<?php echo base_url('admin/vehicules'); ?>"><i class="fa fa-tablet" aria-hidden="true"></i> Véhicules</a></li>
    <li><a href="<?php echo base_url('admin/utilisateurs'); ?>"><i class="fa fa-fire" aria-hidden="true"></i> Utilisateurs</a></li>
    <li><a href="<?php echo base_url('admin/reservation'); ?>"><i class="fa fa-folder-open" aria-hidden="true"></i> Reservations</a></li>
    <li><a href="<?php echo base_url('admin/mails'); ?>"><i class="fa fa-play" aria-hidden="true"></i> Mails</a></li>
     
  </ul>
</div>
</body>
<script>
$(document).ready(function(){
  $(".menu-toggle i").click(function(){
    $(".side-menu").css({
      left: '0px',
      transition: '0.5s'
    });
    $(".menu-toggle i.fa-bars, .menu-toggle i.fa-times").toggle();
  });
  $(".menu-toggle i.fa-times").click(function(){
    $(".side-menu").css({
      left: '-250px',
    });
  });
});
</script>
</html>
