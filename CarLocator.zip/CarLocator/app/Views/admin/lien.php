    <!-- logo onglet -->
    <link href="assets/uploads/LogoCLocator.PNG" rel="icon">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    
    <!-- lien vers fichier CSS -->
    <link href="<?php echo base_url(). '/assets/css/stylePerso.css'; ?>" rel="stylesheet">
    <!-- Fichier JavaScript pour vitrine, image filtre  -->
    <script src="<?php echo base_url(). '/assets/js/main.js ';?>"></script>
    <script src="<?php echo base_url(). '/assets/js/isotope.pkgd.min.js';?>"></script>
    </script>