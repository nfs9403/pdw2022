<!-- The Modal -->
<div class="modal" tabindex="-1" id="inscriptionModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Inscription</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form method="POST" action="<?php echo base_url(); ?>/Home/inscription" name="inscriptionForm" id="inscriptionForm">
    <div class="row">
        <div class="col-sm-4">Lastname</div>
        <div class="col-sm-8"><input class="form-control" type="text" name="lastname" /></div>
    </div>
    <div class="row">
        <div class="col-sm-4">Firstname</div>
        <div class="col-sm-8"><input class="form-control" type="text" name="firstname" /></div>
    </div>
    <div class="row">
        <div class="col-sm-4">Email</div>
        <div class="col-sm-8"><input class="form-control" type="text" name="email" /></div>
    </div>
    <div class="row">
        <div class="col-sm-4">Password</div>
        <div class="col-sm-8"><input class="form-control" type="password" name="password" /></div>
    </div>
    <div class="row">
        <div class="col-sm-4">Repeat Password</div>
        <div class="col-sm-8"><input class="form-control" type="password" name="password2" /></div>
    </div>
</form>
	    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success" onclick="sendForm('inscriptionForm')">Inscription</button>
      </div>
    </div>
  </div>
</div>