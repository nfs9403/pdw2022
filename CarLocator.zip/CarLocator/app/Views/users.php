<html>

<head>
  <title>Aperçu des clients</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  
  <?php 
      include_once('include/lien.php');
  ?>

</head>

<style>
.a{
padding-top:120px ;
}
.abc {
  height:980px;
}

</style>

<body>
  <header>
    <?php
    include_once 'navbar.php';
    ?>
  </header>

<section class="abc">
  <div class=" a container mt-3">
    <h2>Utilisateur inscrit</h2>
    <form class="d-flex">
      <input class="form-control me-sm-2" type="text" placeholder="Essayer avec ajax si temps">
      <button class="btn btn-secondary my-2 my-sm-0" type="submit">Chercher</button>
    </form>
    <table class="table table-hover">
      <thead>
        <tr>
          <th>id</th>
          <th>nom</th>
          <th>Prénom</th>
          <th>email</th>
          <th>Modifier</th>
          <th>Supprimer</th>
        </tr>
      </thead>
      <tbody>
        
        <?php
        foreach ($users as $key => $user) {
          echo '<tr><td>' . $user->id_utilisateur . '</td>';
          echo '<td>' . $user->lastname . '</td>';
          echo '<td>' . $user->firstname . '</td>';
          echo '<td>' . $user->email . '</td>';
          echo '<td><a data-bs-toggle="modal" data-bs-target="#upd' . $user->id_utilisateur . '" class="btn btn-secondary">update</a></td>';
          echo '<td><a data-bs-toggle="modal" data-bs-target="#del' . $user->id_utilisateur . '" class="btn btn-danger">Delete</a></td>';

        ?>


          <!-- MODAL -->
          
          <div class="modal fade" id="upd<?php echo $user->id_utilisateur ?>" tableindex="+1" aria-labelledby="ModalLabel2">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="ModalLabel2">êtes-vous sur de vouloir modifier ce client ?</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="validationCustom01">Nom</label>
                    <input type="text" class="form-control"  placeholder="Nouveau Nom" >
                </div>

                <div class="col-md-4 mb-3">
                    <label for="validationCustom01">Prénom</label>
                    <input type="text" class="form-control"  placeholder="Nouveau Prénom" >
                </div>
                
                <div class="col-md-4 mb-3">
                    <label for="validationCustom01">Adresse Mail</label>
                    <input type="text" class="form-control"  placeholder="nouvelle Email" >
                </div>




                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>

                  <form action="<?php echo base_url(); ?>/home/update/<?php echo $user->id_utilisateur; ?>" method="POST">
                    <button type="submit" class="btn btn-primary">mettre a jour</button>
                  </form>
                </div>
              </div>
            </div>


          <?php
        }
          ?>

      </tbody>
    </table>
  </div>
  </section>

<?php
  include_once('include/footer.php');
  ?>

</body>
<script>

</script>

</html>