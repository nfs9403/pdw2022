<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(){

        $team = new \App\Models\TeamModel();
        $teamArray = $team->findAll();
        $data['teams'] = $teamArray;

        return view('welcome_message',$data);
    }


    public function loginPage(){
        return view('loginPage');
        }


        public function profilModal(){
            return view('profilModal');
            }

    public function voitureInfo(){
    return view('voitureInfo');
    }
    

    public function lien(){
        return view('include/lien');
        }
    

  



public function update($id=null){
    $session = session(); 
    $request = $this->request;

    $usermodel = new \App\Models\UserModel(); 
    $userdata=[
        'id_utilisateur' => $request->getPost('id_utilisateur'),
        'lastname'=> $request->getPost('lastname'), 
        'firstname'=> $request->getPost('firstname'), 
        'email'=> $request->getPost('email')
    ]; 
    $usermodel->where('id_utilisateur', $request->getPost('id_utilisateur'))->update($request->getPost('id_utilisateur'),$userdata); 
    
    return $this->users();
}

    
    public function voitureDetails(){
    return view('voitureDetails');}

    public function veh(){
        $voiture = new \App\Models\voiture();
        $voitureArray = $voiture->findAll();
        $data['voitures'] = $voitureArray;

        $team = new \App\Models\TeamModel();
        $teamArray = $team->findAll();
        $data['teams'] = $teamArray;

    return view('veh',$data);
}
    



    public function vitrine(){
        
        $voiture = new \App\Models\voiture();
        $voitureArray = $voiture->findAll();
        $data['voitures'] = $voitureArray;
    return view('vitrine',$data);}
        

    public function partenaire(){
        return view('partenaire');}






    
    
    public function users(){
      
      $usermodel = new \App\Models\UserModel ();
      $userArray = $usermodel->findAll();
      $data['users'] = $userArray;
      


      return view('users',$data);
    }
     public function login(){
      
      $session = session();
      $request = $this->request;
      $user = \App\Models\Authenticator::authenticate($request->getPost('email'),$request->getPost('password'),$request->getPost('id_role'));
      $session->set('user',$user);
      
      return $this->index();
      
    }
    public function inscription(){
        $request = $this->request;
        $usermodel = new \App\Models\UserModel();
        $passwordHashed = password_hash($request->getPost('password'), PASSWORD_BCRYPT);
        $userdata=['lastname'=> $request->getPost('lastname'),
            'firstname'=> $request->getPost('firstname'),
            'email'=> $request->getPost('email'),
            'password'=>$passwordHashed,
            'id_role'=>3];
        $usermodel->insert($userdata);
        return $this->index();
    }
    public function logout(){
        $session = session();
        $session->destroy();
        return $this->index();
    }
}





