<?php

namespace App\Controllers;

class Admin extends BaseController
{


    public function AdminHome(){
        $session = session();
        return view('admin/AdminHome');
    }

    public function utilisateurs(){

        $usermodel = new \App\Models\UserModel ();
        $userArray = $usermodel->findAll();
        $data['users'] = $userArray;

        return view('admin/utilisateurs',$data);
    }


    


    public function vehicules(){
    
        $voiture = new \App\Models\voiture();
        $voitureArray = $voiture->findAll();
        $data['voitures'] = $voitureArray;
        
        $categorie = new \App\Models\vehCatModel();
        $catArray = $categorie->findAll();
        $data['categories'] = $catArray;
        

        return view('admin/vehicules',$data);
    }

    public function entreprise(){
        return view('admin/entreprise');
    }

    public function reservation(){
        return view('admin/reservation');
    }

    public function mails(){
        return view('admin/Mails');
    }



    public function login(){
      
        $session = session();
        $request = $this->request;
        $user = \App\Models\Authenticator::authenticate($request->getPost('email'),$request->getPost('password'));
        $session->set('user',$user);
        
        return $this->acceuil();
        
      }



      public function delete($id = null){ 
        $usermodel = new \App\Models\UserModel(); 
        $request = $this->request; 
        $user=$usermodel->find($request->getPost('id_utilisateur')); 
        $usermodel->where('id_utilisateur', $id)->delete(); 
        
        return $this->utilisateurs(); 

}







    
}